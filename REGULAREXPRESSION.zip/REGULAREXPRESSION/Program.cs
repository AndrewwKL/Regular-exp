﻿using System.Text.RegularExpressions;

namespace REGEX_EXAMPLES
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string fileOne = GetFileText("segmentation_file_2nd_pass_1");
            string fileTwo = GetFileText("segmentation_file_2nd_pass_2");
            string fileThree = GetFileText("segmentation_file_2nd_pass_3");

            Regex rx = new Regex(@"[\d]{1,2},[\d]{0,3}");
            Regex rxDos = new Regex(@"\b\d\.");
            Regex rxTres = new Regex(@"\$\.\d{0,2}");

            if (rx.IsMatch(fileThree)|| rxDos.IsMatch(fileThree)||rxTres.IsMatch(fileThree))
            {
                Console.WriteLine("Match!");
            }
            else
            {
                Console.WriteLine("No Match!");
            }

            Match match = rx.Match(fileOne);
            if (match.Success)
            {
                Console.WriteLine("Match Value: " + match.Value);
            }


        }

        private static string GetFileText(string fileName)
        {
            var reader = new StreamReader(@"" + fileName + ".txt");
            var json = reader.ReadToEnd();
            reader.Dispose();
            return json;
        }
    }
}